﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SwitchScene : MonoBehaviour
{
    public Canvas errorCanvas;
    private const float ecX = 763.17f;  // canvas default position X
    private const float ecY = 188.25f;  // canvas default position Y

    public bool CheckInitialize()
    {
        ShowError(-2000, "");
        GetInput inputs = new GetInput();
        if (GameObject.Find("targetinput").GetComponent<InputField>().text.Length < 4 || GameObject.Find("targetinput").GetComponent<InputField>().text.Length > 30)
        {
            ShowError(100, "Indica la frase objetivo de entre 4 y 30 caracteres");
            return false;
        }
        
        if (GameObject.Find("popSize input").GetComponent<InputField>().text.Length <= 0 || int.Parse(GameObject.Find("popSize input").GetComponent<InputField>().text) <= 30)
        {
            ShowError(50, "Introduce el tamaño de la población mayor a 30");
            return false;
        }

        if(GameObject.Find("elitism input").GetComponent<InputField>().text.Length <= 0 || int.Parse(GameObject.Find("elitism input").GetComponent<InputField>().text) <= 0)
        {
            ShowError(0, "El elitismo tiene que ser positivo");
            return false;
        }
        if (int.Parse(GameObject.Find("elitism input").GetComponent<InputField>().text) > int.Parse(GameObject.Find("popSize input").GetComponent<InputField>().text))
        {
            ShowError(0, "El elitismo tiene que ser menor al tamaño de la población");
            return false;
        }
        ShowError(-2000, "");
        return true;
    }

    public void ShowError(float yTrans, string message)
    {
        //Debug.Log(errorCanvas.transform.position.x);
        //Debug.Log(errorCanvas.transform.position.y);
        //Debug.Log(errorCanvas.transform.position.z);
        errorCanvas.transform.position = new Vector3(ecX, ecY + yTrans + 1000, 0);//new Vector3(968.2f, 1337.5f + yTrans, 0);
        errorCanvas.GetComponentInChildren<InputField>().placeholder.color = new Color(1, 0, 0, 1);
        errorCanvas.GetComponentInChildren<InputField>().placeholder.GetComponent<Text>().text = message;
    }

    public void StartSentenceBuilder()
    {
        TestShakespeare test = new TestShakespeare();

        switch (test.getState())
        {
            case (-1):
                if (CheckInitialize())
                {
                    test.setState(0);
                }
                break;

            case (2):
                GetInput parameters = new GetInput();
                parameters.reset();
                GameObject.Find("buttonFrase").GetComponentInChildren<Text>().text = "Start";
                test.setState(-1);
                SceneManager.LoadScene(4);

                break;

            default:
                break;
        }
    }

    public void volver()
    {
        TestShakespeare test = new TestShakespeare();
        test.setState(-1);
        SceneManager.LoadScene(2);
    }

}