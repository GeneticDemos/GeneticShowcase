using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class TestShakespeare : MonoBehaviour
{

    [Header("Genetic Algorithm")]
    [SerializeField] string targetString;
    string validCharacters = "123467890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ,.|!#$%&/()=? ";
    [SerializeField] int populationSize;
	[SerializeField] float mutationRate;
	[SerializeField] int elitism;

	[Header("Other")]
	[SerializeField] int numCharsPerText;
    [SerializeField] Text targetText;
	[SerializeField] Text bestText;
	[SerializeField] Text bestFitnessText;
	[SerializeField] Text numGenerationsText;
	[SerializeField] Transform populationTextParent;
	[SerializeField] Text textPrefab;

	private GeneticAlgorithm<char> ga;
	private System.Random random;

    static int state = -1;

    public void setState(int st)
    {
        state = st;
    }

    public int getState()
    {
        return state;
    }

    void Update()
	{
        if (state == 0)
        {
            //--------Aqui empieza el awake
            
            GetInput parameters = new GetInput();
            targetString = GameObject.Find("targetinput").GetComponent<InputField>().text;
            populationSize = int.Parse(GameObject.Find("popSize input").GetComponent<InputField>().text);
            mutationRate = parameters.getMutRate();
            elitism = int.Parse(GameObject.Find("elitism input").GetComponent<InputField>().text);

            targetText.text = targetString;
            numCharsPerTextObj = numCharsPerText / validCharacters.Length;
            if (numCharsPerTextObj > populationSize) numCharsPerTextObj = populationSize;

            int numTextObjects = Mathf.CeilToInt((float)populationSize / numCharsPerTextObj);

            for (int i = 0; i < numTextObjects; i++)
            {
                textList.Add(Instantiate(textPrefab, populationTextParent));
            }

            ///--------Aqui empieza el start

            if (string.IsNullOrEmpty(targetString))
            {
                Debug.LogError("Target string is null or empty");
                this.enabled = false;
            }
            
            random = new System.Random();
            ga = new GeneticAlgorithm<char>(populationSize, targetString.Length, random, GetRandomCharacter, FitnessFunction, elitism, mutationRate);
            setState(1);
        }

        if (state == 1)
        {
            ga.NewGeneration();

            UpdateText(ga.BestGenes, ga.BestFitness, ga.Generation, ga.Population.Count, (j) => ga.Population[j].Genes);

            if (ga.BestFitness == 1)
            {
                GameObject.Find("buttonFrase").GetComponentInChildren<Text>().text = "Reset";
                setState(2);
            }
        }
        if (state == 2)
        {

        }

	}

	private char GetRandomCharacter()
	{
		int i = random.Next(validCharacters.Length);
		return validCharacters[i];
	}

	private float FitnessFunction(int index)
	{
		float score = 0;
		DNA<char> dna = ga.Population[index];

		for (int i = 0; i < dna.Genes.Length; i++)
		{
			if (dna.Genes[i] == targetString[i])
			{
				score += 1;
			}
		}

		score /= targetString.Length;

		score = (Mathf.Pow(2, score) - 1) / (2 - 1);

		return score;
	}

	private int numCharsPerTextObj;
    private List<Text> textList = new List<Text>();

    private void UpdateText(char[] bestGenes, float bestFitness, int generation, int populationSize, Func<int, char[]> getGenes)
	{
		bestText.text = CharArrayToString(bestGenes);
		bestFitnessText.text = (100*bestFitness).ToString();

		numGenerationsText.text = generation.ToString();

		for (int i = 0; i < textList.Count; i++)
		{
			var sb = new StringBuilder();
			int endIndex = i == textList.Count - 1 ? populationSize : (i + 1) * numCharsPerTextObj;
			for (int j = i * numCharsPerTextObj; j < endIndex; j++)
			{
				foreach (var c in getGenes(j))
				{
					sb.Append(c);
				}
				if (j < endIndex - 1) sb.AppendLine();
			}

			textList[i].text = sb.ToString();
		}
	}

	private string CharArrayToString(char[] charArray)
	{
		var sb = new StringBuilder();
		foreach (var c in charArray)
		{
			sb.Append(c);
		}

		return sb.ToString();
	}

    public void GetInput(string new_text)
    {
        targetString = new_text;
        Debug.Log("has entrat: " + new_text);
    }
}
