﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GetInput : MonoBehaviour {
   
    public Slider mutRate;
    public InputField mutation;

    static string targetString;
    static int populationSize = 0;
    static float mutationRate = 0.5f;
    static int elitism = 0;

    public void reset()
    {
        GameObject.Find("targetinput").GetComponent<InputField>().Select();
        GameObject.Find("targetinput").GetComponent<InputField>().text = "";

        GameObject.Find("popSize input").GetComponent<InputField>().Select();
        GameObject.Find("popSize input").GetComponent<InputField>().text = "";

        GameObject.Find("elitism input").GetComponent<InputField>().Select();
        GameObject.Find("elitism input").GetComponent<InputField>().text = "";


        targetString = null;
        populationSize = 0;
        elitism = 0;
    }

    public void setMutRate(float val)
    {
        mutationRate = mutRate.value;
        mutation.placeholder.GetComponent<Text>().text = mutationRate.ToString();
        mutation.placeholder.color = new Color(0,0,0, 1);
    }

    public float getMutRate()
    {
        return mutationRate;
    }

}
